(function () {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // header shadow on scroll
  const header = document.getElementById('siteHeader');
  if (header) {
    window.addEventListener('scroll', () => header.classList.toggle('scrolled', window.scrollY > 8));
  }

  // mobile nav
  const burger = document.getElementById('burgerBtn');
  const navLinks = document.getElementById('navLinks');
  if (burger && navLinks) {
    burger.addEventListener('click', (event) => {
      event.stopPropagation();
      navLinks.classList.toggle('open');
    });
  }

  // search panel
  const searchToggle = document.getElementById('searchToggle');
  const searchPanel = document.getElementById('searchPanel');
  const searchInput = document.getElementById('searchInput');
  const searchSuggestions = document.getElementById('searchSuggestions');
  if (searchToggle && searchPanel) {
    searchToggle.addEventListener('click', (event) => {
      event.stopPropagation();
      searchPanel.classList.toggle('open');
      if (searchPanel.classList.contains('open')) document.getElementById('searchInput')?.focus();
    });
  }

  if (searchInput && searchSuggestions) {
    // The product list is one cached file (/search-index.json), downloaded the first time search is opened.
    let searchProducts = [];
    let searchLoading = false;
    const searchHost = searchSuggestions.parentElement;
    try {
      // older pages that still embed the list keep working
      searchProducts = JSON.parse(searchHost?.dataset.searchProducts || '[]');
    } catch (error) {
      searchProducts = [];
    }
    function loadSearchIndex() {
      const src = searchHost?.dataset.searchSrc;
      if (!src || searchProducts.length || searchLoading) return;
      searchLoading = true;
      fetch(src)
        .then((res) => (res.ok ? res.json() : []))
        .then((list) => {
          searchProducts = Array.isArray(list) ? list : [];
          if (searchInput.value.trim()) searchInput.dispatchEvent(new Event('input'));
        })
        .catch(() => {})
        .finally(() => { searchLoading = false; });
    }
    searchInput.addEventListener('focus', loadSearchIndex);
    searchToggle?.addEventListener('click', loadSearchIndex);

    searchInput.addEventListener('input', () => {
      loadSearchIndex();
      const terms = searchInput.value.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
      searchSuggestions.replaceChildren();

      if (!terms.length) {
        searchSuggestions.hidden = true;
        return;
      }

      const matches = searchProducts
        .filter((product) => {
          const text = (product.searchText || product.name).toLocaleLowerCase();
          return terms.every((term) => text.includes(term));
        })
        .slice(0, 5);

      if (!matches.length) {
        const emptyMessage = document.createElement('p');
        emptyMessage.className = 'search-empty';
        emptyMessage.textContent = 'No products found';
        searchSuggestions.append(emptyMessage);
      }

      matches.forEach((product) => {
        const link = document.createElement('a');
        link.className = 'search-suggestion';
        link.href = `/ecommerce/product/${encodeURIComponent(product.slug)}`;
        link.setAttribute('role', 'option');

        const thumbnail = document.createElement('span');
        thumbnail.className = 'search-suggestion-thumb';
        if (product.image) {
          const image = document.createElement('img');
          image.src = product.image;
          image.alt = '';
          image.loading = 'lazy';
          thumbnail.append(image);
        } else {
          thumbnail.textContent = product.name?.charAt(0) || '';
          thumbnail.setAttribute('aria-hidden', 'true');
        }

        const name = document.createElement('span');
        name.className = 'search-suggestion-name';
        name.textContent = product.name;

        const price = document.createElement('span');
        price.className = 'search-suggestion-price';
        price.textContent = product.price;

        link.append(thumbnail, name, price);
        searchSuggestions.append(link);
      });

      searchSuggestions.hidden = false;
    });
  }

  // cart drawer
  const drawer = document.getElementById('cartDrawer');
  const overlay = document.getElementById('overlay');
  const cartOpen = document.getElementById('cartOpen');
  const drawerClose = document.getElementById('drawerClose');
  function closeDrawer(){
    if (drawer) drawer.classList.remove('open');
    if (overlay) overlay.classList.remove('open');
    document.body.classList.remove('cart-open');
  }
  if (cartOpen && drawer && overlay) {
    cartOpen.addEventListener('click', () => { drawer.classList.add('open'); overlay.classList.add('open'); document.body.classList.add('cart-open'); });
  }
  if (drawerClose) {
    drawerClose.addEventListener('click', closeDrawer);
  }
  if (overlay) {
    overlay.addEventListener('click', closeDrawer);
  }

  document.addEventListener('click', (event) => {
    const target = event.target;
    // a click on something the page just redrew (e.g. the cart's quantity buttons) leaves the page; it was not an outside click
    if (target && target.isConnected === false) return;
    const clickedOnNav = navLinks && navLinks.contains(target);
    const clickedOnBurger = burger && burger.contains(target);
    const clickedOnSearchToggle = searchToggle && searchToggle.contains(target);
    const clickedOnSearchPanel = searchPanel && searchPanel.contains(target);
    const clickedOnCartButton = cartOpen && cartOpen.contains(target);
    const clickedOnCartDrawer = drawer && drawer.contains(target);
    const clickedOnOverlay = overlay && overlay.contains(target);

    if (navLinks && !clickedOnNav && !clickedOnBurger && navLinks.classList.contains('open')) {
      navLinks.classList.remove('open');
    }

    if (searchPanel && !clickedOnSearchToggle && !clickedOnSearchPanel && searchPanel.classList.contains('open')) {
      searchPanel.classList.remove('open');
    }

    if (drawer && !clickedOnCartButton && !clickedOnCartDrawer && !clickedOnOverlay && drawer.classList.contains('open')) {
      closeDrawer();
    }
  });

  // rotating hero headline — phrases come from Site Settings, passed in
  // via a data attribute so this script has no hardcoded copy in it.
  const heroCycle = document.getElementById('heroCycle');
  if (heroCycle) {
    let heroPhrases = [];
    try {
      heroPhrases = JSON.parse(heroCycle.dataset.phrases || '[]');
    } catch (error) {
      heroPhrases = [];
    }

    if (heroPhrases.length > 1) {
      let heroPhraseIndex = 0;

      const rotateHeroPhrase = () => {
        heroCycle.style.opacity = '0';
        heroCycle.style.transform = 'translateY(10px)';

        setTimeout(() => {
          heroPhraseIndex = (heroPhraseIndex + 1) % heroPhrases.length;
          heroCycle.textContent = heroPhrases[heroPhraseIndex];
          heroCycle.style.opacity = '1';
          heroCycle.style.transform = 'translateY(0)';
        }, 180);
      };

      heroCycle.classList.add('fade');

      if (!reduceMotion) {
        setInterval(rotateHeroPhrase, 2600);
      }
    }
  }

  // product card "add to cart" buttons: adds the minimum order quantity and opens the cart
  document.addEventListener('click', (event) => {
    const btn = event.target.closest && event.target.closest('button[data-card-add]');
    if (!btn || !window.LashtribeCart) return;
    const id = btn.dataset.cardAdd;
    if (!id) return;
    window.LashtribeCart.add(id, Math.max(1, Number(btn.dataset.moq) || 1));
    btn.classList.add('added');
    setTimeout(() => btn.classList.remove('added'), 1200);
    if (drawer) drawer.classList.add('open');
    if (overlay) overlay.classList.add('open');
    document.body.classList.add('cart-open');
  });

  const drawerCheckoutBtn = document.getElementById('drawerCheckoutBtn');
  if (drawerCheckoutBtn) {
    drawerCheckoutBtn.addEventListener('click', () => {
      closeDrawer();
      if (window.LashtribeCart) {
        window.LashtribeCart.goToCheckout();
        return;
      }
      window.location.href = '/ecommerce/checkout';
    });
  }

  if (window.LashtribeCart) {
    window.LashtribeCart.syncCartBadges();
  }

  // scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  if (reduceMotion){
    revealEls.forEach(el => el.classList.add('in-view'));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  }
})();
